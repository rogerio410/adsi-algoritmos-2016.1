def main():
	inicio = input("A0: ")
	limite = input("limite: ")
	r = input("R: ")
	P_A(A0,limite,r)

def P_A(limite,limite,r):
	for i in range(limite,limite,r):
		print i 

if __name__ == '__main__':
	main()
