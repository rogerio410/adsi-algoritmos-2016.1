def recursivo(numero):

    n1 = 0
    n2 = 1
    if numero == 1:
        return 0
    else:
        print(n1,n2)
        for i in range(qtd-2)
            atual = n1+n2
            n1 = n2
            n2 = atual
            print(atual)
def main():
    n = input(int("n: "))
    recursivo(n)

if __name__ == '__main__':
	recursivo()
