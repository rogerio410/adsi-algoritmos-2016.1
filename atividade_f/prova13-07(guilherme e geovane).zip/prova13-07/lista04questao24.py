

def pa(inicio,limite,razao):

	for i in range(inicio,limite+1,razao):
		print (i)


def main():
	inicio, limite , razao  = int(input("")),int(input("")),int(input(""))
	pa(inicio,limite,razao)

if __name__ == '__main__':
	main()
