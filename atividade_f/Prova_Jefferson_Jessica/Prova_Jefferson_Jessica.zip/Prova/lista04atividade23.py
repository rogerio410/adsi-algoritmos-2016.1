'''Escreva um algoritmo que leia a razão de uma PG (Progressão Geométrica) e o seu primeiro termo e
escreva os N termos da PG. Ler o valor de N.'''

def main():
    limite = int(input('Informe um limite: '))
    razao = int(input('Informe a razão: '))
    for pg in range(1, limite +1):
        print(pg)





if __name__ == '__main__':
    main()