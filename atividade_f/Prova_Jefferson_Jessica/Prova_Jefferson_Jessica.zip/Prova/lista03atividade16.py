'''Leia um número N, calcule e escreva os N primeiros termos de seqüência de Fibonacci
(0,1,1,2,3,5,8,...). O valor lido para N sempre será maior ou igual a 2.'''
def main():
    quatidade_termos = int(input('Informe a quantidade de termos: '))


def fibonacci(quantidade_termos):


if __name__ == '__main__':
    main()