def main():
	A0 = input("Digite o valor inicial: ")
	Limite = input("Digite o Limite:")
	Razao = input("Digite a Razao: ")
	for i in range(A0, Limite, Razao):
		print i

if __name__ == '__main__':
	main()