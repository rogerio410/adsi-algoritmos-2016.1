def main():
	print "Um programa para ler N e escrever todos os numeros de 1 a N"
	Numero = input("Digite N: ")
	for i in range(1, Numero + 1):
		print i

if __name__ == '__main__':
	main()